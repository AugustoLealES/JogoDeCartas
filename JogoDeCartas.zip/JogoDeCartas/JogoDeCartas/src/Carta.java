public class Carta {
  private Naipe naipe;
  private Valor valor;
  private boolean aberto;

  public Carta(Naipe naipe, Valor valor){
    this.naipe = naipe;
    this.valor = valor;
    this.aberto = true;
  }

  public Naipe getNaipe() {
    return naipe;
  }

  public void setNaipe(Naipe naipe) {
    this.naipe = naipe;
  }

  public Valor getValor() {
    return valor;
  }

  public void setValor(Valor valor) {
    this.valor = valor;
  }

  public boolean isAberto() {
    return aberto;
  }

  public void setAberto(boolean aberto) {
    this.aberto = aberto;
  }

  public void viraCarta(){
    aberto = !aberto;  
  }

  public boolean ehMaior(Carta outra) {
    if(valor.ordinal() > outra.getValor().ordinal()) {
      return true;
    }
    return false;
  }

  public boolean ehIgual(Carta outra) {
    if(valor.ordinal() == outra.getValor().ordinal()) {
      return true;
    }
    return false;
  }

  public void retiraCarta() {

  }

  @Override
  public String toString() {
    return "Carta [naipe=" + naipe + ", valor=" + valor + ", aberto=" + aberto + "]";
  }
}
