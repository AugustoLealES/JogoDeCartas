public class App {
    public static void main(String[] args) throws Exception {
        Jogar jogar = new Jogar();

        jogar.distribuiCartas();

        jogar.jogaCartas();

        jogar.Contagem();
        
    }
}
