public class Baralho {
  private Deck cartas;

  public Baralho() {
    cartas = new Deck();
      for(Naipe naipe:Naipe.values()) {
        for(Valor valor:Valor.values()) {
          Carta carta = new Carta(naipe, valor);
          cartas.insereEmBaixo(carta);
          System.out.println(carta);
        }
      }
    }

  public int qndadeDeCartas(){
    return cartas.qndadeDeCartas();
  }

  public Carta retiraDeCima() {
    return cartas.retiraDeCima();
  }

  public boolean vazio() {
    return cartas.vazio();
  }

  public Baralho embaralha() {
    cartas.embaralha();
    return this; //CHAMA E RETORNA A PROPRIA CLASSE APLICANDO ISSO À VARIÁVEL DE INSTÂNCIA
  }

  @Override
  public String toString() {
    return "Baralho [cartas=" + cartas + "]";
  }
}
