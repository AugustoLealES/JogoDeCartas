import java.util.Random;

public class Deck {
  private Random random;
  public final int TAMANHO = 52; //TAMANHO DE 2 BARALHOS
  private Carta[] cartas;
  private int ultimaCarta;

  public Deck() {
    cartas = new Carta[TAMANHO];
    ultimaCarta = 0;
    random = new Random();
  }

  public boolean insereEmBaixo(Carta carta) {
    if(ultimaCarta < TAMANHO){
      cartas[ultimaCarta] = carta;
      if(carta.isAberto()){
        carta.viraCarta();
      }
      ultimaCarta++;
      return true;
    }
    return false;
  }

  public Carta retiraDeCima() {
    //SE O DECK ESTÁ VAZIO RETORNA NULL
    if(ultimaCarta == 0) {
      return null;
    }
    // SE TEM, TIRA DE CIMA
    Carta deCima = cartas[0];
    for(int i=0; i < ultimaCarta-2; i++) {
      cartas[i] = cartas[i+1];
    }

    ultimaCarta--;
    cartas[ultimaCarta] = null;
    return deCima;    
  }

  public int qndadeDeCartas() {
    return ultimaCarta;
  }

  public boolean vazio() {
    return ultimaCarta == 0;
  }

  public Carta retiraCarta() {
    Carta deCima = cartas[0];
    for(int i=0; i < ultimaCarta-2; i++) {
      cartas[i] = cartas[i+1];
    }

    ultimaCarta--;
    cartas[ultimaCarta] = null;
    return deCima;    
  }

  public void embaralha() {
    int vezes = 40000;
    while(vezes > 0) {
      int posicao1 = random.nextInt(qndadeDeCartas());
      int posicao2 = random.nextInt(qndadeDeCartas());
      Carta aux = cartas[posicao1];
      cartas[posicao1] = cartas[posicao2];
      cartas[posicao2] = aux;
      vezes--;
    }
    // List<Carta> list = new LinkedList<>(Arrays.asList(cartas));
    // Collections.shuffle(list);
    // cartas = list.toArray(Carta[]::new);
  }
}
