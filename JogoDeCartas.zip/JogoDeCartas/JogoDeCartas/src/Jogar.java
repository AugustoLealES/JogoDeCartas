import java.util.Random;

public class Jogar {
  Random random = new Random();
  Deck pilhaEmpate; 
  Baralho baralho;
  Deck jogador1, jogador2;
  int vitoriaJogador1 = 0, vitoriaJogador2 = 0, empate = 0;

  public void Contagem(){
    System.out.println("Vitorias do jogador 1: " + vitoriaJogador1);
    System.out.println("Vitorias do jogador 2: " + vitoriaJogador2);
    System.out.println("Empates: " + empate);
    System.out.println(jogador1.qndadeDeCartas());
    System.out.println(jogador2.qndadeDeCartas());

  }

  public Jogar() {
    baralho = new Baralho().embaralha(); //RETORNA A INSTÂNCIA APLICANDO O EMBARALHA
    jogador1 = new Deck(); //CRIA OS DECKS DOS JOGADORES
    jogador2 = new Deck(); 
    pilhaEmpate = new Deck();
  }

  //DISTRIBUI TODAS AS CARTAS ENTRE DOIS JOGADORES
  public void distribuiCartas() {
    while(!baralho.vazio()){
      jogador1.insereEmBaixo(baralho.retiraDeCima());
      jogador2.insereEmBaixo(baralho.retiraDeCima());
    }
  }

  //LOOP DO JOGO
  public void jogaCartas() {
    int rodada = 1;
    boolean acabou = false;
    while(!acabou) {
      System.out.println("");
      System.out.println("Rodada: " + rodada);

      //PEGA CARTA DE CADA JOGADOR
      Carta cj1 = jogador1.retiraDeCima();
      Carta cj2 = jogador2.retiraDeCima();
      cj1.viraCarta();
      cj2.viraCarta();
      System.out.println("Carta do jogador 1: " + cj1);
      System.out.println("Carta do jogador 2: " + cj2);
    
    //COMPARA SE CARTA DO JOGADOR 1 É MAIOR, SE É ELE GANHA
    
    
    if(cj1.ehMaior(cj2)) {

      System.out.println("Jogador 1 ganhou a rodada!");

      vitoriaJogador1++;

      int ordem = random.nextInt(2);
      
      switch(ordem) { //COLOCAR ALEATORIAMENTE AS CARTAS EM BAIXO DO BARALHO
        case 0: jogador1.insereEmBaixo(cj2);
                jogador1.insereEmBaixo(cj1); 
                break; 
        case 1: jogador1.insereEmBaixo(cj1);
                jogador1.insereEmBaixo(cj2);
                break;
      }
    }else if(cj2.ehMaior(cj1)) { 
      
      System.out.println("Jogador 2 ganhou a rodada!");

      vitoriaJogador2++;

      int ordem = random.nextInt(2);
      switch(ordem) { //COLOCAR ALEATORIAMENTE AS CARTAS EM BAIXO DO BARALHO
        case 0: jogador2.insereEmBaixo(cj1);
                jogador2.insereEmBaixo(cj2); 
                break;
        case 1: jogador2.insereEmBaixo(cj2);
                jogador2.insereEmBaixo(cj1); 
                break;
      }
    }

    else {
    System.out.println("Empate na rodada!");
    pilhaEmpate.insereEmBaixo(cj2);
    pilhaEmpate.insereEmBaixo(cj1);
    empate++;

    int ordem = random.nextInt(2);
    switch (ordem) {
        case 0:
            jogador1.insereEmBaixo(pilhaEmpate.retiraDeCima());
            jogador2.insereEmBaixo(pilhaEmpate.retiraDeCima());
            break;
        case 1:
            jogador2.insereEmBaixo(pilhaEmpate.retiraDeCima());
            jogador1.insereEmBaixo(pilhaEmpate.retiraDeCima());
            break;
    }

    jogador1.retiraCarta();
    jogador2.retiraCarta();
    
    
}
    rodada++;

    if(jogador1.vazio() || jogador2.vazio()) {
      acabou = true;
    }
  }

  System.out.println("");
  if(vitoriaJogador1 > vitoriaJogador2 && vitoriaJogador1 > empate) {
    System.out.println("O Jogador 1 ganhou com " + vitoriaJogador1 + " vitórias!");
  } else if(vitoriaJogador1 < vitoriaJogador2 && vitoriaJogador1 > empate) {
    System.out.println("O Jogador 2 ganhou com " + vitoriaJogador2 + " vitórias!");
  } else if(empate > vitoriaJogador1 && empate > vitoriaJogador2) {
    System.out.println("Empate de " + empate + " pontos!");
  }
  
  System.out.println("Fim");

  
  //ENTREGAR ATE DOMINGO A 24H00
  }
}